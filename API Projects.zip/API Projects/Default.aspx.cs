﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Teradata.Client.Provider;

public partial class _Default : System.Web.UI.Page
{

    public TdConnection teraconnection;

    public string strtdconn;
    public TdCommand tdcommand;
    public TdDataAdapter tdAdapter;
    public TdDataReader tdReader;
    protected void Page_Load(object sender, EventArgs e)
    {
        DisplayTeraDatarecords();
    }


    public void DisplayTeraDatarecords()
    {


        try
        {

            TdConnectionStringBuilder connectionStringBuilder = new TdConnectionStringBuilder();
            connectionStringBuilder.DataSource = "TDPROD.server.rbsgrp.net";
            connectionStringBuilder.Database = "ACS_EDW_TIER1";
            connectionStringBuilder.UserId = "JOHNCRY";
            connectionStringBuilder.Password = hdnpass.Value;
            connectionStringBuilder.AuthenticationMechanism = "LDAP";
            

            using (TdConnection cn = new TdConnection())
            {
                cn.ConnectionString = connectionStringBuilder.ConnectionString;
                cn.Open();

                TdCommand cmd = cn.CreateCommand();
                cmd.CommandText = "SELECT DATE";

                using (TdDataReader reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    DateTime date = reader.GetDate(0);
                    //Console.WriteLine("Teradata Database DATE is {0}", date);
                    lblquery.Text = "Teradata Database DATE is {0}" + date;

                }
            }
        }
        catch (Exception ex)
        {

        }


    }
}