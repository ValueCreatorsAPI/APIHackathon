﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Summary description for clsRegisteration
/// </summary>
public class clsRegisteration : sqlhelper
{
	public clsRegisteration()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    
    #region Declation
    public SqlCommand cmd;
    public SqlDataAdapter da;
    public DataSet ds;
    public DataTable dt;
    public SqlParameter par1;
    string Query;
    sqlhelper objsqlhelper= new sqlhelper(); 
    #endregion

    

    public int InsertAuditTrail(string Month, int Year, int BU, int UpdatedBy)
    {
        try
        {
            int i = 0;
            SqlParameter[] _sqlParamArray = new SqlParameter[4];
            _sqlParamArray[0] = new SqlParameter("@Month", Month);
            _sqlParamArray[1] = new SqlParameter("@Year", Year);
            _sqlParamArray[2] = new SqlParameter("@BU", BU);
            _sqlParamArray[3] = new SqlParameter("@UpdatedBy", UpdatedBy);
            i = objsqlhelper.ExecuteScalar("InsertAuditTrail", _sqlParamArray);
            return i;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }


    

    public int InsertUpdateUserMaster(string FirstName, string LastName,string CorpID, int BUID, string Mail, string Role, int status, int CreatedBy)
    {
        try
        {
            int i = 0;
            SqlParameter[] _sqlParamArray = new SqlParameter[8];
            _sqlParamArray[0] = new SqlParameter("@FirstName", FirstName);
            _sqlParamArray[1] = new SqlParameter("@LastName", LastName);
            _sqlParamArray[2] = new SqlParameter("@CorpID", CorpID);
            _sqlParamArray[3] = new SqlParameter("@BUID", BUID);
            _sqlParamArray[4] = new SqlParameter("@Mail", Mail);
            _sqlParamArray[5] = new SqlParameter("@Role", Role);
            _sqlParamArray[6] = new SqlParameter("@status", status);
            _sqlParamArray[7] = new SqlParameter("@CreatedBy", CreatedBy);
            i = objsqlhelper.ExecuteScalar("InsertUpdateUserMaster", _sqlParamArray);
            return i;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }



    public int InsertProdData(string ProdName, string racf, string EmpID, string empname, string empemail, string option)
    {
        try
        {
            int i = 0;
            SqlParameter[] _sqlParamArray = new SqlParameter[6];
            _sqlParamArray[0] = new SqlParameter("@ProdName", ProdName);
            _sqlParamArray[1] = new SqlParameter("@racf", racf);
            _sqlParamArray[2] = new SqlParameter("@EmpID", EmpID);
            _sqlParamArray[3] = new SqlParameter("@empname", empname);
            _sqlParamArray[4] = new SqlParameter("@empemail", empemail);
            _sqlParamArray[5] = new SqlParameter("@option", option);
            i = objsqlhelper.ExecuteScalar("WDInsertProdSel", _sqlParamArray);
            return i;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }



    public DataSet GetProdUpdateDetails(string racf)
    {
        try
        {
            SqlParameter[] _sqlParamArray = new SqlParameter[1];
            _sqlParamArray[0] = new SqlParameter("@racf", racf);
          
            ds = objsqlhelper.ExecuteDataSet("GetProdRegdetails", _sqlParamArray);
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }

    public DataSet GetFCBTxns(string Accno, string srtcode, string Amount, string Datefrom, string DateTo)
    {
        try
        {
            SqlParameter[] _sqlParamArray = new SqlParameter[5];
            _sqlParamArray[0] = new SqlParameter("@AccNo", Accno);
            _sqlParamArray[1] = new SqlParameter("@SrtCode", srtcode);
            _sqlParamArray[2] = new SqlParameter("@Amount", Amount);
            _sqlParamArray[3] = new SqlParameter("@Datefrom", Datefrom);
            _sqlParamArray[4] = new SqlParameter("@DateTo", DateTo);
            ds = objsqlhelper.ExecuteDataSet("Sel_FCBTxns", _sqlParamArray);
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }


    public DataSet GetReport(string updatedby)
    {
        try
        {
            SqlParameter[] _sqlParamArray = new SqlParameter[1];
            _sqlParamArray[0] = new SqlParameter("@UpdatedBy", updatedby);
            ds = objsqlhelper.ExecuteDataSet("Sel_FCBReport", _sqlParamArray);
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }
    

        public DataSet checkprodregistration(string racf)
    {
        try
        {
            SqlParameter[] _sqlParamArray = new SqlParameter[1];
             _sqlParamArray[0] = new SqlParameter("@racf", racf);
            ds = objsqlhelper.ExecuteDataSet("GetProdRegforRACF", _sqlParamArray);
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }
    public DataSet GetProducts()
    {
        try
        {
            SqlParameter[] _sqlParamArray = new SqlParameter[0];
           // _sqlParamArray[0] = new SqlParameter("@UpdatedBy", updatedby);
            ds = objsqlhelper.ExecuteDataSet("GetProduct");
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }

    public DataSet Getdatalocaldb(string Accountnumber, string sortcode, string frmdate, string todte, string frmamt, string toamt)
    {
        try
        {
            SqlParameter[] _sqlParamArray = new SqlParameter[6];
            _sqlParamArray[0] = new SqlParameter("@AccNo", Accountnumber);
            _sqlParamArray[1] = new SqlParameter("@SortCode", sortcode);
            _sqlParamArray[2] = new SqlParameter("@frmdate", frmdate);
            _sqlParamArray[3] = new SqlParameter("@todate", todte);
            _sqlParamArray[4] = new SqlParameter("@Amountfrm", frmamt);
            _sqlParamArray[5] = new SqlParameter("@Amountto", toamt);
            ds = objsqlhelper.ExecuteDataSet("Sel_Teradataset", _sqlParamArray);
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }

}
