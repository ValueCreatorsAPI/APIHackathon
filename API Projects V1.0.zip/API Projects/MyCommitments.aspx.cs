﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class MyCommitments : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ReadXMLdoc("scheduledPayments");
      
    }

    protected void ddltxns_changed(object sender, EventArgs e)
    {
        string txnname = ddltxns.SelectedItem.Value;
        ReadXMLdoc(txnname);
    }

    public void ReadXMLdoc(string txnname)
    {
        
        int i = 0;
        DataTable dt1 = new DataTable();
        
        string FileName = Server.MapPath("//Data//data.xml");
       
        XmlReader xmlFile;
        xmlFile = XmlReader.Create(FileName, new XmlReaderSettings());
        DataSet ds = new DataSet();
        ds.ReadXml(xmlFile);

        for (i = 0; i <= ds.Tables.Count - 1; i++)
        {
            string tblname = ds.Tables[i].TableName;
            if(tblname == txnname)
            {
                if (tblname == "standingOrders")
                {
                    divSO.Visible = true;
                    divDD.Visible = false;
                    divSP.Visible = false;
                    //  DataTable dt2 = ds.Tables.Add("standingOrders");

                    gvtxnsSO.DataSource = ds.Tables[i];
                    gvtxnsSO.DataBind();
                }
                else if (tblname == "directDebits")
                {
                    divDD.Visible = true;
                    divSO.Visible = false;
                    divSP.Visible = false;
                    // DataTable dt2 = ds.Tables.Add("directDebits");

                    gvtxnsDD.DataSource = ds.Tables[i];
                    gvtxnsDD.DataBind();
                }
                else if (tblname == "scheduledPayments")
                {
                    divDD.Visible = false;
                    divSO.Visible = false;
                    divSP.Visible = true;
                    // DataTable dt2 = ds.Tables.Add("scheduledPayments");

                    gvtxnsSP.DataSource = ds.Tables[i];
                     gvtxnsSP.DataBind();
                }
            }
        }

       
    }


    private static DataTable RemoveEmptyRows(DataTable source)
{
        DataTable dt1 = source.Clone(); //copy the structure 
        for (int i = 0; i <= source.Rows.Count - 1; i++) //iterate through the rows of the source
        {
            DataRow currentRow = source.Rows[i];  //copy the current row 
            foreach (var colValue in currentRow.ItemArray)//move along the columns 
            {
               
                if (!string.IsNullOrEmpty(colValue.ToString())) // if there is a value in a column, copy the row and finish
                {
                    dt1.ImportRow(currentRow);
                    break; //break and get a new row                        
                }
            }
        }
        return dt1;
    }
}