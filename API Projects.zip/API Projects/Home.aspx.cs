﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Net.Mail;
using System.IO;
using Teradata.Client.Provider;

using System.Data.Odbc;
using System.Data.Common;
using System.Data.SqlClient;
using System.Configuration;

public partial class Home : System.Web.UI.Page
{
    public TdDataAdapter tdAdapter;
    public TdDataReader tdReader;

    public DbDataAdapter dbAdapter;
    public DbDataReader dbReader;

    
    protected void Page_Load(object sender, EventArgs e)
    {
        clsRegisteration ObjclsRegisteration = new clsRegisteration();
        sqlhelper objsqlhelper = new sqlhelper();

      

        if (!IsPostBack)
        {
            //ScriptManager.GetCurrent(this).RegisterPostBackControl(this.ddlOverdraft);

            string SysDomainName = Request.ServerVariables["AUTH_USER"].ToString();

            if ((SysDomainName == "") || (SysDomainName == null))
            {
                SysDomainName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            }

            string[] LoginDetails = SysDomainName.Split('\\');
            ViewState["Racf"] = LoginDetails[1].ToString();

            txtDomain.Text = LoginDetails[0].ToString();
            txtRACF.Text = LoginDetails[1].ToString();

           
          //  checkprodregistration(LoginDetails[1].ToString());

            getproducts();

        }
    }


    public void checkprodregistration(string racf)
    {
        clsRegisteration ObjclsRegisteration = new clsRegisteration();
        DataSet ds = new DataSet();

        ds = ObjclsRegisteration.checkprodregistration(racf);


       if (ds.Tables.Count> 0)
        {
           // Response.Redirect("pg_Ackng.aspx?Msg=1", false);
           
        }
       
    }

    public void getproducts()
    {
        clsRegisteration ObjclsRegisteration = new clsRegisteration();
        DataSet ds = new DataSet();
       
        ds = ObjclsRegisteration.GetProducts();

        rptProducts.DataSource = ds;
        rptProducts.DataBind();
    }
   


   

    protected void btnexport_click(object sender, EventArgs e)
    {

        try
        {
            clsRegisteration ObjclsRegisteration = new clsRegisteration();
        DataSet ds = new DataSet();
        string racf = Convert.ToString(ViewState["Racf"]);
        ds = ObjclsRegisteration.GetReport(racf);

        grdReport.DataSource = ds;
        grdReport.DataBind();


            grdReport.Visible = true;

            Response.ClearContent();
            Response.Buffer = true;
            Response.Charset = "";
            Response.AddHeader("content-disposition", string.Format("attachment;filename={0}", "Report.xls"));
            Response.ContentType = "application/ms-excel";
            System.IO.StringWriter sw = new System.IO.StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            grdReport.HeaderRow.Style.Add("background-color", "#FFFFFF");
            grdReport.RenderControl(htw);
            Response.Write(sw.ToString());
            Response.Flush();
            Response.End();

            //  Response.Flush();
            //HttpContext.Current.ApplicationInstance.CompleteRequest();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    protected void btnSearchTeradata_click(object sender, EventArgs e)
    {


       

      

    }

    protected void btnAddProd_Click(object sender, EventArgs e)
    {
        string prodcode = "";
        int cntsel = 0;

        foreach (RepeaterItem item in rptProducts.Items)
        {

         //   CheckBox ckChoose1 = item.FindControl("ckChoose") as CheckBox;
          //   string ProdId = ckChoose1.NamingContainer.UniqueID.ToString();

            CheckBox ckChoose1 = item.FindControl("chkAddProd") as CheckBox;
          
            if (ckChoose1.Checked == true)
            {
                cntsel = cntsel + 1;
            }

            if (cntsel > 1)
            {
                ShowAlertMessage("Please select either one product.");
                ckChoose1.Checked = false;

            }
        }
    }

    protected string GetImageName(string ProductCode)
    {
        string path = Server.MapPath("Images//" + ProductCode.ToString() + ".jpg");
        return File.Exists(path) ? ProductCode : "noimage";
    }

    protected void btnsubmit_click(object sender, EventArgs e)
    {
        clsRegisteration ObjclsRegisteration = new clsRegisteration();

            int i = 0;
        string prodname = "";
            string Amount = string.Empty;
        string option = "";
        foreach (RepeaterItem item in rptProducts.Items)
        {
            RadioButtonList ckChoose1 = item.FindControl("chkAddProd") as RadioButtonList;
            for (int j = 0; j < ckChoose1.Items.Count; j++)
            {
                if (ckChoose1.Items[j].Selected == true)
                {
                    option = ckChoose1.Items[j].Text;
                    Label lblProdName = item.FindControl("lblProdNme") as Label;
                    prodname = lblProdName.Text;
                }
            }

        }
        string empid = txtEmpID.Text;
        string empname = txtEmpName.Text;
        string empmail = txtEmpEmail.Text;
        string RACF = txtRACF.Text;
        // string option = txtRACF.Text;
        if (option == "")
        {
            ShowAlertMessage("Kindly choose either one option.");
        }
        else
        {
            i = ObjclsRegisteration.InsertProdData(prodname, RACF, empid, empname, empmail, option);

            if (i >= 0)
            {

                Response.Redirect("pg_Ackng.aspx?Msg=2", false);
            }
            else
            {
                ShowAlertMessage("NOT submitted");
            }
        }

        
    }

    #region exporttoexcel

    public override void VerifyRenderingInServerForm(Control control)
    {
        // base.VerifyRenderingInServerForm(control);
    }
    public override void RenderControl(HtmlTextWriter writer)
    {
        base.RenderControl(writer);
    }
    protected override void RenderChildren(HtmlTextWriter writer)
    {
        base.RenderChildren(writer);
    }
    protected void ExporttoExcel_Click(object sender, EventArgs e)
    {
        try
        {
            grdReport.Visible = true;

            Response.ClearContent();
            Response.Buffer = true;
            Response.Charset = "";
            Response.AddHeader("content-disposition", string.Format("attachment;filename={0}", "Report.xls"));
            Response.ContentType = "application/ms-excel";
            System.IO.StringWriter sw = new System.IO.StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            grdReport.HeaderRow.Style.Add("background-color", "#FFFFFF");
            grdReport.RenderControl(htw);
            Response.Write(sw.ToString());
            Response.Flush();
            Response.End();

            //  Response.Flush();
            //HttpContext.Current.ApplicationInstance.CompleteRequest();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    #endregion

    //protected void dgvtxns_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
    //    string TxnCode = Convert.ToString(dgvtxns.DataKeys[row.RowIndex].Values["TxnCode"]);

    //   // ShowAlertMessage("Charge Back submitted");

    //    txtAccountnumber.Text = string.Empty;
    //    txtbranchsortcode.Text = string.Empty;
    //    txtAmount.Text = string.Empty;
    //    txtfromDate.Value = "";
    //    txtToDate.Value = "";

    //    DataSet ds = null;
    //    dgvtxns.DataSource = ds;
    //    dgvtxns.DataBind();




    //}

    public static void ShowAlertMessage(string error)
    {
        Page page = HttpContext.Current.Handler as Page;
        if (page != null)
        {
            error = error.Replace("'", "\'");
            ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + error + "');", true);
        }
    }

    //public void promptfunc()
    //{
    //    string url = "PopUP.aspx";
    //    string s = "window.open('" + url + "', 'popup_window', 'width=500,height=500,left=100,top=100,resizable=yes');";
    //    ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    //}

    public void SendMail()
    {
        bool success = false;
        MemoryStream ms = new MemoryStream();
        try
        {
            MailMessage message = new MailMessage();


            byte[] bytes = System.Convert.FromBase64String(Base64string.Text.ToString());



            message.From = new MailAddress("noreply@rbs.com", "Bereavement Form");
            message.To.Add(new MailAddress("johncry@rbos.co.uk", "Christo"));
            //message.To.Add(new MailAddress(txtStaffEmail.Text, "Bereavement Team"));

            //ms = ddd();
            //ms.Position = 0;
            //message.Attachments.Add(new Attachment(ms,"Bereavement.pdf"));


            message.IsBodyHtml = true;
            message.Subject = "Bereavement Form";
            //string id = Convert.ToString(UsrEmpId);
            //string idlink = "EmpId=";
            //Url = Url + idlink + Server.UrlEncode(Encrypt.Encryption(id)) + SHMail + SHEmail + servID + serID + surNme + Surname + survID + SurID;

            StringBuilder strMailBody = new StringBuilder();
            strMailBody.AppendFormat("<BODY style=\"margin: 20px; font-family: Arial; font-size: 10px; color: #002469; background: #FFF;\">");
            //strMailBody.AppendFormat("<TABLE border=0 cellSpacing=0 cellPadding=0 width=\"100%\" bgColor=#E6E6E6><TBODY><TR><TD><BR><TABLE style=\"BORDER-BOTTOM: rgb(237,237,237) 1px solid; BORDER-LEFT: rgb(237,237,237) 1px solid; LINE-HEIGHT: 17px; BORDER-COLLAPSE: collapse;FONT-FAMILY: arial; FONT-SIZE: 12px; BORDER-TOP: rgb(237,237,237) 1px solid; BORDER-RIGHT: rgb(237,237,237) 1px solid\"border=1 cellSpacing=0 cellPadding=0 width=800 bgColor=#ffffff><TBODY><TR><TD><TABLE border=0 cellSpacing=0 cellPadding=5 width=\"100%\" bgColor=#dae7ef><TBODY><TR><TD align=\"right\" style=\"COLOR: #c9c9c9;\"><B><A style=\"FONT-FAMILY: arial; COLOR:#05316D; FONT-SIZE: 30px; TEXT-DECORATION: none\">NPS Survey</A></B></TD></TR></TBODY></TABLE>");
            strMailBody.AppendFormat("<TABLE border=0 cellSpacing=0 cellPadding=0><TBODY><TR><TD><TABLE border=0 cellSpacing=0 cellPadding=15><TBODY><TR><TD><TABLE border=0 cellSpacing=0 cellPadding=0 width=\"100%\"><TBODY><TR><TD vAlign=top><DIV style=\"LINE-HEIGHT: 16px; FONT-FAMILY: Arial, Helvetica, sans-serif; MARGIN-BOTTOM: 6px; FONT-SIZE: 13px\">Dear User,<BR><BR>");
            //strMailBody.Append("Your have been recommended by " + Convert.ToString(Session[VariableConstants.SessionVariable.UserName])+ "  as some one who would be in a good position to provide feedback on "+Convert.ToString(ddlReportees.SelectedItem.Text)+". ");
            strMailBody.Append(" <Label ForeColor = #002469> Please find the Bereavement Form attached </Label>");
            strMailBody.AppendFormat("<BR>");
            strMailBody.AppendFormat("<BR>");
            strMailBody.AppendFormat("</i></td></tr>");
            strMailBody.Append("<tr><td style=\"line-height: 16px; font-family: Arial, Helvetica, sans-serif; margin-bottom: 6px;font-size: 13px\"><BR><BR>Many Thanks,<BR> </td></tr></DIV></TD></TR><TR><TD height=20 colSpan=2><FONT color=#0000ff size=2></FONT></TD></TR></TBODY></TABLE><TABLE border=0 cellSpacing=0 cellPadding=0><TBODY><TR><TD width=683><DIV align=\"center\" style=\"FONT-FAMILY: arial; COLOR: rgb(0,0,0); FONT-SIZE: 11px\"><A style=\"COLOR: #006b9c; TEXT-DECORATION: none\">This is an auto-generated email. Please do not reply to this message.</A><BR></DIV></TD></TR></TBODY></TABLE></DIV></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV></DIV><BR><BR></DIV></DIV></DIV></BODY>");

            message.Body = Convert.ToString(strMailBody);
            SmtpClient client = new SmtpClient("REMACENTMA01.server.rbsgrp.net");
            try
            {
                client.Send(message);



                success = true;
            }
            catch (Exception ex)
            {
                ShowAlertMessage("Mail not sent" + ex.Message);

            }
        }
        catch (Exception ex)
        {

            ShowAlertMessage("Send Failure" + ex.Message);

        }

        try
        {
            if (success)
            {
                ShowAlertMessage("Mail Sent Successfully");

                byte[] array = ms.ToArray();
                ViewState["ByteArrayforDownload"] = array;
                ms.Close();

                //Response.Clear();
                //Response.ContentType = "application/pdf";
                //Response.AddHeader("content-disposition", "attachment;" +
                //                               "filename=sample.pdf");
                //Response.Cache.SetCacheability(HttpCacheability.NoCache);
                //Response.BinaryWrite(array);
                //Response.End();

            }
        }
        catch (Exception ex)
        {

            ShowAlertMessage("Error in Downloading the File" + ex.Message);
        }


    }






    protected void Button1_Click(object sender, EventArgs e)
    {
        SendMail();

    }

    protected void txtEmpID_TextChanged(object sender, EventArgs e)
    {
        Service.EMPDATA_SERVICESoapClient Serv = new Service.EMPDATA_SERVICESoapClient();
        DataSet dt = new DataSet();
        dt = Serv.GetEmployeeData(Convert.ToString(txtEmpID.Text));
        if (dt.Tables[0].Rows.Count > 0)
        {

            txtEmpName.Text = Convert.ToString(dt.Tables[0].Rows[0]["FirstName"]) + " " + Convert.ToString(dt.Tables[0].Rows[0]["LastName"]);
            txtEmpEmail.Text = Convert.ToString(dt.Tables[0].Rows[0]["EmployeeEmail"]);
           // btnSubmit.Enabled = true;
        }
        else
        {

            ShowAlertMessage("Please check your Corp Id");
           // btnSubmit.Enabled = false;
        }

    }
}