﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Data;


public partial class Cashflow : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ReadXMLdoc("transactions");
    }

    protected void ddltxns_changed(object sender, EventArgs e)
    {
        string txnname = ddltxns.SelectedItem.Value;
        ReadXMLdoc(txnname);
    }

    public void ReadXMLdoc(string txnname)
    {

        int i = 0;
        DataTable dt1 = new DataTable();
        string FileName = Server.MapPath("//Data//data.xml");

        XmlReader xmlFile;
        xmlFile = XmlReader.Create(FileName, new XmlReaderSettings());
        DataSet ds = new DataSet();
        ds.ReadXml(xmlFile);

        for (i = 0; i <= ds.Tables.Count - 1; i++)
        {


            string tblname = ds.Tables[i].TableName;
            if (tblname == "transactions")
            {
                if (tblname == "transactions")
                {
                   
                    DataTable dtnew = new DataTable();
                    DataTable dt3 = ds.Tables["transactions"].Clone();
                  

                    foreach (DataRow dr in ds.Tables["transactions"].Rows)
                    {
                       string crdits = dr["cdtDbtInd"].ToString();
                       

                        if (crdits == "CRDT")
                        {
                            if (txnname == "Standard")
                            {
                                string dte = dr["bookingDate"].ToString();
                                string varinc = dr["remittanceInf"].ToString();
                                DateTime txndte = Convert.ToDateTime(dte);

                               int mnthsdiff = GetMonthDifference(DateTime.Now, txndte);

                                if ((varinc != "Other Income") || (varinc != "Sale Credit"))
                                {
                                    DataRow drNew = dt3.NewRow();
                                    dt3.ImportRow(dr);
                                }
                            }
                            else if (txnname == "Variable")
                            {
                                string dte = dr["bookingDate"].ToString();
                                string varinc = dr["remittanceInf"].ToString();
                                DateTime txndte = Convert.ToDateTime(dte);

                                int mnthsdiff = GetMonthDifference(DateTime.Now, txndte);

                                if((varinc == "Other Income") || (varinc == "Sale Credit"))
                                {
                                    DataRow drNew = dt3.NewRow();
                                    dt3.ImportRow(dr);
                                }
                            }
                            else
                            {
                                DataRow drNew = dt3.NewRow();
                                dt3.ImportRow(dr);
                            }
                        }
                       
                        
                    }

                    divSO.Visible = true;
                    
                    gvtxnsSO.DataSource = dt3;
                    gvtxnsSO.DataBind();
                }
               
            }
        }


    }

    public static int GetMonthDifference(DateTime startDate, DateTime endDate)
    {
        int monthsApart = 12 * (startDate.Year - endDate.Year) + startDate.Month - endDate.Month;
        return Math.Abs(monthsApart);
    }


   
}