﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;


/// <summary>
/// Summary description for DAL
/// </summary>

public class sqlhelper
{
    #region connectinstring
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conString"].ConnectionString);
   //SqlConnection TeradataconString = new SqlConnection(ConfigurationManager.ConnectionStrings["conStringTera"].ConnectionString);

    #endregion

    SqlCommand cmd;
    DataSet ds;
    SqlDataAdapter ada;

    // To Execute the insert,delete and update sql quseries

    public Boolean ExecuteQuery(string Procedurename, SqlParameter[] _ParamArray)
    {
        try
        {
            con.Open();
            cmd = new SqlCommand(Procedurename, con);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in _ParamArray)
            {
                cmd.Parameters.Add(p);
            }
            int i = cmd.ExecuteNonQuery();
            con.Close();
            return true;
        }
        catch (Exception ex)
        {
            return false;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }

    

    public Boolean ExecuteQueryNP(string Procedurename)
    {
        try
        {
            con.Open();
            cmd = new SqlCommand(Procedurename, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteScalar();
            con.Close();
            return true;
        }
        catch (Exception ex)
        {
            return false;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }


    public Boolean Execute_Query(string Query)
    {
        try
        {
            con.Open();
            cmd = new SqlCommand(Query , con);           
            int i = cmd.ExecuteNonQuery();
            con.Close();
            return true;
        }
        catch (Exception ex)
        {
            return false;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }

    }



    // Fill the Dataset without parameter
    public DataSet ExecuteDataSet(String ProcedureName)
    {
        ds = new DataSet();
        try
        {
            //ds = null;
            cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds, "TableGet");
            return ds;
        }
        catch (Exception)
        {
            return ds;
        }

    }

    // Fill the Dataset with parameters
    public DataSet ExecuteDataSet(String ProcedureName, SqlParameter[] _ParamArray)
    {
        ds = new DataSet();
        try
        {
            // ds = null;
            cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in _ParamArray)
            {
                cmd.Parameters.Add(p);
            }
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds, "TableGet");
            return ds;
        }
        catch
        {
            return ds;
        }

    }


    public DataSet ExecuteDataSet_Parameter(String ProcedureName,int year ,int QTR,string Lname )
    {
        ds = new DataSet();
        try
        {
            // ds = null;
            cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (year!= 0)
            {
                cmd.Parameters.AddWithValue("@Qtr", QTR);
            }
            if(QTR !=0)
            {
                cmd.Parameters.AddWithValue("@year", year); 
            }

            if (Lname != "")
            {
                cmd.Parameters.AddWithValue("@LManger", Lname);
            }
          
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds, "TableGet");
            return ds;
        }
        catch
        {
            return ds;
        }

    }

    // execute the Executescalar 
    public int ExecuteScalar(String ProcedureName, SqlParameter[] _ParamArray)
    {

        try
        {
            con.Open();
            cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter p in _ParamArray)
            {
                cmd.Parameters.Add(p);
            }
            cmd.ExecuteScalar();
            return 1;

        }
        catch
        {
            return 0;
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }


    // execute the Executescalar 
    public string ExecuteScalarNP(String ProcedureName)
    {

        try
        {
            con.Open();
            cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.StoredProcedure;
            return cmd.ExecuteScalar().ToString();

        }
        catch
        {
            return "0";
        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }




    public DataSet ExecuteDataSet1()
    {
        ds = new DataSet();
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("sp_core_procname", con);
            cmd.CommandType = CommandType.StoredProcedure;
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;


        }
        catch
        {
            return ds;
        }

    }
    public DataSet ExecuteDataSet2(int var_Pid)
    {
        ds = new DataSet();
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_core_act", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@processid", var_Pid);
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }
        catch
        {
            return ds;
        }

    }
    public DataSet ExecuteDataSet3()
    {
        ds = new DataSet();
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("sp_Noncore_act", con);
            cmd.CommandType = CommandType.StoredProcedure;
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;


        }
        catch
        {
            return ds;
        }
    }
    public DataSet ExecuteDataSet4(int var_Pid)
    {
        ds = new DataSet();
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("sp_core_actcycle", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Activity", var_Pid);
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;


        }
        catch
        {
            return ds;
        }

    }

    public DataSet ExecuteDataSet5(DateTime time, DateTime date, int user)
    {
        ds = new DataSet();
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("sp_user", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@day", date);
            cmd.Parameters.AddWithValue("@time", time);
            cmd.Parameters.AddWithValue("@userId", user);
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds);
            con.Close();
            return ds;
        }
        catch
        {
            return ds;
        }

    }
    public DataSet ExecuteDataSetbyquery(String ProcedureName)
    {
        ds = new DataSet();
        try
        {
            //  ds = null;
            cmd = new SqlCommand(ProcedureName, con);
            cmd.CommandType = CommandType.Text;
            ada = new SqlDataAdapter(cmd);
            ada.Fill(ds, "TableGet");
            return ds;
        }
        catch (Exception)
        {
            return ds;
        }

    }



    public DataSet DsSelect(string query)
    {
        con.Open();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(query, con);
        da.Fill(ds);
        if (con.State == ConnectionState.Open)
            con.Close();
        return (ds);
    }

    public DataTable DtSelect(string query)
    {
        con.Open();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(query, con);
        da.Fill(ds);
        if (con.State == ConnectionState.Open)
            con.Close();
        return (ds.Tables[0]);
    }


    public void populateDDL(string query, DropDownList ddl)
    {
        try
        {
            DataTable data = new DataTable();
            data = DtSelect(query);
            ddl.Items.Clear();
            ddl.Items.Add(new ListItem("Select", "-1"));
            if (data.Rows.Count > 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    ddl.Items.Add(new ListItem(data.Rows[i][0].ToString(), data.Rows[i][1].ToString()));
                }
            }
        }
        catch
        {
           
        }
    }

    public void populateDDL_Reports(string query, DropDownList ddl)
    {
        try
        {
            DataTable data = new DataTable();
            data = DtSelect(query);
            ddl.Items.Clear();
            ddl.Items.Add(new ListItem("All", "-1"));
            if (data.Rows.Count > 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    ddl.Items.Add(new ListItem(data.Rows[i][0].ToString(), data.Rows[i][1].ToString()));
                }
            }
        }
        catch
        {

        }
    }


}
