﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Data;

public partial class PalTellerPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ReadXMLdoc("transactions");
    }



    protected void btnRecom_click(object sender, EventArgs e)
    {

        Response.Redirect("SpendAPP.aspx");

    }

    public void ReadXMLdoc(string txnname)
    {

        int i = 0;
        decimal val = 0;
        decimal val2 = 0;
        DataTable dt1 = new DataTable();
        string FileName = Server.MapPath("//Data//data.xml");

        XmlReader xmlFile;
        xmlFile = XmlReader.Create(FileName, new XmlReaderSettings());
        DataSet ds = new DataSet();
        ds.ReadXml(xmlFile);

        for (i = 0; i <= ds.Tables.Count - 1; i++)
        {
            string tblname = ds.Tables[i].TableName;
            if (tblname == "transactions")
            {
                if (tblname == "transactions")
                {
                    DataTable dtnew = new DataTable();
                    DataTable dt3 = ds.Tables["transactions"].Clone();

                    foreach (DataRow dr in ds.Tables["transactions"].Rows)
                    {
                        string crdits = dr["cdtDbtInd"].ToString();
                        if (crdits == "DBIT")
                        {
                            decimal TotIncome = Convert.ToDecimal(dr["amount"].ToString());
                            val = val + Convert.ToDecimal(TotIncome);
                            lblTotExp.Text = "Total Expenses for Month: " + val;
                           
                        }
                       else if (crdits == "CRDT")
                        {
                            decimal TotIncome = Convert.ToDecimal(dr["amount"].ToString());
                            val2 = val2 + Convert.ToDecimal(TotIncome);
                            lblavgincome.Text = "Average Monthly Income: " + val2 / 12;

                        }
                    }

                    decimal netval = val2 - val;

                    lblNet.Text = "Net: " + netval;
                    
                }

            }
        }


    }


}